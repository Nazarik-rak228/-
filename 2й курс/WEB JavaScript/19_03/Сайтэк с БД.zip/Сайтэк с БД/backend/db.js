// backend/db.js
const { Pool } = require('pg');
require('dotenv').config();

// Принудительно преобразуем все параметры в строки
const config = {
    host: String(process.env.DB_HOST || 'localhost'),
    port: parseInt(process.env.DB_PORT || '5432', 10),
    user: String(process.env.DB_USER || 'postgres'),
    password: String(process.env.DB_PASSWORD || ''), // Ключевая строка!
    database: String(process.env.DB_NAME || 'postgres'),
};

// Для отладки (уберите после решения проблемы)
console.log('DB Config:', {
    host: config.host,
    port: config.port,
    user: config.user,
    database: config.database,
    hasPassword: !!config.password
});

const pool = new Pool(config);

// Проверка подключения
pool.connect((err, client, release) => {
    if (err) {
        console.error('❌ Ошибка подключения к БД:', err.message);
        console.error('Проверьте пароль в файле .env');
    } else {
        console.log('✅ Успешное подключение к PostgreSQL');
        release();
    }
});

module.exports = pool;