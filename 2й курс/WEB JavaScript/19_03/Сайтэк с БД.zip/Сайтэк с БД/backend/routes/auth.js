const express = require('express');
const router = express.Router();
const pool = require('../db');

// Регистрация
router.post('/register', async (req, res) => {
    // try {
    // const { full_name, email, login, password, role } = req.body;

    // const result = await pool.query(
    // 'SELECT register_user($1, $2, $3, $4, $5) AS message',
    // [full_name, email, login, password, role]
    // );

    // res.json({ message: result.rows[0].message });
    // } catch (error) {
    // console.error(error);
    // res.status(500).json({ error: 'Ошибка регистрации' });
    // }


    try {
        const { full_name, email, login, password, role } = req.body;


        const roleResult = await pool.query('SELECT id FROM roles WHERE name = $1', [role]);
        
        if (roleResult.rows.length === 0) {
            return res.status(400).json({ error: 'Неверная роль' });
        }
        
        const role_id = roleResult.rows[0].id;


        const checkUser = await pool.query('SELECT id FROM users WHERE login = $1 OR email = $2', [login, email]);
        if (checkUser.rows.length > 0) {
            return res.status(400).json({ error: 'Логин или Email уже заняты' });
        }


        await pool.query(
            'INSERT INTO users (full_name, email, login, password, role_id) VALUES ($1, $2, $3, $4, $5)',
            [full_name, email, login, password, role_id]
        );

        res.json({ message: 'Регистрация успешна' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Ошибка регистрации' });
    }
});

// Авторизация
router.post('/login', async (req, res) => {
    // try {
    //     const { login, password } = req.body;

    //     const result = await pool.query(
    //     'SELECT * FROM authorize_user($1, $2)',
    //     [login, password]
    // );

    //     const user = result.rows[0];

    //     if (!user || !user.id) {
    //         return res.status(401).json({ message: 'Неверный логин или пароль' });
    //     }

    //     res.json({
    //         message: user.auth_status,
    //         user: {
    //             id: user.user_id,
    //             full_name: user.full_name,
    //             email: user.email,
    //             role: user.role
    //         }
    //     });
    // } catch (error) {
    //     console.error(error);
    //     res.status(500).json({ error: 'Ошибка авторизации' });
    // }
     try {
        const { login, password } = req.body;

        // Ищем пользователя и сразу берем название роли через JOIN
        const result = await pool.query(`
            SELECT u.id, u.full_name, u.email, r.name as role 
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.login = $1 AND u.password = $2
        `, [login, password]);

        const user = result.rows[0];

        if (!user) {
            return res.status(401).json({ message: 'Неверный логин или пароль' });
        }

        res.json({
            message: 'Вход выполнен',
            user: {
                id: user.id,
                full_name: user.full_name,
                email: user.email,
                role: user.role 
            }
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Ошибка авторизации' });
    }
});

    module.exports = router;