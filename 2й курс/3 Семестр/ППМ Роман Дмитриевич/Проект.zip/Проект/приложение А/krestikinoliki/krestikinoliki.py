# Игра крестики-нолики выполнена студентами группы П-8-24: Векличевой Оксаной, Сюткиной Варарой, Мелеховым Олегом, Дмитриевым Антоном.
from tkinter import *
from datetime import datetime

okno = Tk()  # создаем окно игры
okno.title("Крестики-нолики")  # называем окно
okno.geometry("300x450")  # задаем размеры для окна: ширина х высота
okno.configure(bg='#FFE4E1')

pole = [0,0,0,0,0,0,0,0,0]  # будущее поле, с пустыми ячейками
tek_player = "X"  # кто сейчас ходит
game_over = False  # для обозначения окончания игры

x_pobeda = 0  # победы за крестики
o_pobeda = 0  # победы за нолики
nicha = 0  # счет ничьих
vse_igri = []  # список всех игр

knopki = []  # кнопки (ячейки) на поле

def proverka_na_pobedu():
    # Проверяем все линии где может быть победа
    if (pole[0] == pole[1] == pole[2] != 0 or  # верхняя линия
        pole[3] == pole[4] == pole[5] != 0 or  # средняя линия  
        pole[6] == pole[7] == pole[8] != 0 or  # нижняя линия
        pole[0] == pole[3] == pole[6] != 0 or  # левая вертикаль
        pole[1] == pole[4] == pole[7] != 0 or  # средняя вертикаль
        pole[2] == pole[5] == pole[8] != 0 or  # правая вертикаль
        pole[0] == pole[4] == pole[8] != 0 or  # диагональ слева направо
        pole[2] == pole[4] == pole[6] != 0):   # диагональ справа налево
        return True
    else:
        return False

def proverka_na_nichu():
    # проверяем, есть ли пустые клетки на поле
    pust_kletki = 0
    for kletka in pole:
        if kletka == 0:
            pust_kletki += 1
    return pust_kletki == 0

def sohranit_igru(resultat):
    # сохраняем результат игры
    data_igri = datetime.now().strftime("%d.%m.%Y %H:%M")
    igra_data = {
        "data": data_igri,
        "resultat": resultat,
        "pole": pole.copy()
    }
    vse_igri.append(igra_data)#добавляет в список игры

def obnovit_statistiku():
    # обновляем статистику на экране
    statistika_text = f"X: {x_pobeda} | O: {o_pobeda} | Ничьи: {nicha}"
    label_statistika.config(text=statistika_text)

def pokazat_istoriu():
    # показываем историю игр
    history_okno = Toplevel(okno)
    history_okno.title("История игр")
    history_okno.geometry("350x400")
    
    if not vse_igri:
        Label(history_okno, text="Пока нет сыгранных игр").pack(pady=20)
        return
    
    # Показываем последние игры
    text_area = Text(history_okno, width=40, height=20)
    text_area.pack(pady=10)
    for i, igra in enumerate(reversed(vse_igri[-10:]), 1): #добавляем счетчик игр и переворачиваем его
        text_area.insert(END, f"Игра {i} ({igra['data']})\n")# добавляем строки с форматированием
        text_area.insert(END, f"Результат: {igra['resultat']}\n")
        text_area.insert(END, "---\n") #добавляем строчку

def knopka_click(number):
    global tek_player, game_over, x_pobeda, o_pobeda, nicha
    # Если игра уже закончилась, ничего не делаем
    if game_over:
        return
    # Если клетка уже занята, ничего не делаем
    if pole[number] != 0:
        return
    # Ставим крестик или нолик на поле
    pole[number] = tek_player
    # Показываем крестик или нолик на кнопке
    knopki[number].config(text=tek_player)
    
    # Проверяем победу
    if proverka_na_pobedu():
        label_status.config(text="Победил " + tek_player + "!")
        game_over = True
        # Увеличиваем счетчик побед
        if tek_player == "X":
            x_pobeda = x_pobeda + 1
        else:
            o_pobeda = o_pobeda + 1
        # Сохраняем результат игры
        sohranit_igru(tek_player)
        
    # Проверяем ничью
    elif proverka_na_nichu():
        label_status.config(text="Ничья!")
        game_over = True
        nicha = nicha + 1
        sohranit_igru("Ничья")
        
    # Если игра продолжается
    else:
        # Меняем игрока
        if tek_player == "X":
            tek_player = "O"
        else:
            tek_player = "X"
        # Показываем кто ходит следующий
        label_status.config(text="Ходит: " + tek_player)
    # Обновляем статистику на экране
    obnovit_statistiku()

def novaya_igra():
    global pole, tek_player, game_over
    # Очищаем поле
    pole = [0,0,0,0,0,0,0,0,0]
    tek_player = "X"
    game_over = False
    # Очищаем кнопки
    for knopka in knopki:
        knopka.config(text="")
    label_status.config(text="Ходит: X")

def sbros_statistiki():
    global x_pobeda, o_pobeda, nicha, vse_igri
    x_pobeda = 0
    o_pobeda = 0
    nicha = 0
    vse_igri = []
    obnovit_statistiku()
    label_status.config(text="Статистика сброшена")

# Создаем игровое поле
frame_pole = Frame(okno)
frame_pole.pack(pady=20)

for i in range(3):
    for j in range(3):
        nomer_kletki = i * 3 + j
        knopka = Button(frame_pole, text="", font=("Arial", 20), 
                       width=3, height=1,
                       command=lambda num=nomer_kletki: knopka_click(num))
        knopka.grid(row=i, column=j, padx=2, pady=2)
        knopki.append(knopka)

# Строка статуса
label_status = Label(okno, text="Ходит: X", font=("Arial", 14),bg='#FFE4E1')
label_status.pack(pady=10)

# Статистика
label_statistika = Label(okno, text="X: 0 | O: 0 | Ничьи: 0", font=("Arial", 12), bg='#FFE4E1')
label_statistika.pack()

# Кнопки управления
frame_knopki = Frame(okno,bg='#FFE4E1')
frame_knopki.pack(pady=20)
Button(frame_knopki, text="Новая игра", command=novaya_igra).pack(pady=5)
Button(frame_knopki, text="Сбросить статистику", command=sbros_statistiki).pack(pady=5)
Button(frame_knopki, text="История игр", command=pokazat_istoriu).pack(pady=5)

# Запускаем игру, постоянно отслеживает все события
okno.mainloop()

