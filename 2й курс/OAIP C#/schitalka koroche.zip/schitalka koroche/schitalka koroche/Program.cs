﻿// See https://aka.ms/new-console-template for more information

using System;

 Console.WriteLine("Здравствуйте, добро пожаловать в калькулятор!");
        Console.WriteLine("Введите первое число");
        double a = double.Parse(Console.ReadLine());
        Console.WriteLine("Введите желаемую операцию");
        Console.WriteLine("Доступные операции:");
        Console.WriteLine("Сложение: +");
        Console.WriteLine("Вычитание: -");
        Console.WriteLine("Умножение: *");
        Console.WriteLine("Деление: /");
        Console.WriteLine("Деление с остатком: %");
        string simvol = Console.ReadLine();
        Console.WriteLine("Введите второе число");
        double b = double.Parse(Console.ReadLine());
switch (simvol)
{
    case "+":
        Console.WriteLine(a + b);
        break;
    case "-":
        Console.WriteLine(a - b);
        break;
    case "*":
        Console.WriteLine(a * b);
        break;
    case "/":
        if (b != 0)
        {
            Console.WriteLine(a / b);
        }

        else
        {
            Console.WriteLine("Ай-я-яй, на ноль делить нельзя");
        }
        break;
    case "%":
        if (b != 0)
        {
            Console.WriteLine(a % b);
        }

        else
        {
            Console.WriteLine("Ай-я-яй, на ноль делить нельзя");
        }
        break;
    default: Console.WriteLine("Калькулятор работает только с преведенными выше операциями!");
        break;
}







