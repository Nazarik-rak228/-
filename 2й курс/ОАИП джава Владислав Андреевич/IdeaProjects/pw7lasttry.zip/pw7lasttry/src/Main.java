import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        ProductService productService = new ProductService();
        UserService userService = new UserService();
        FileService fileService = new FileService();

        fileService.loadProducts(productService);
        fileService.loadUsers(userService);

        System.out.println("1. Регистрация");
        System.out.println("2. Авторизация");

        int choice = scanner.nextInt();
        scanner.nextLine();

        if (choice == 1) {
            userService.register(scanner);
        }

        if (!userService.login(scanner)) {
            System.out.println("Неверный логин или пароль");
            return;
        }

        while (true) {
            System.out.println("---------------------------------------------------------------------");
            System.out.println("1. Добавить товар");
            System.out.println("2. Показать товары");
            System.out.println("3. Редактировать");
            System.out.println("4. Удалить");
            System.out.println("5. Сохранить");
            System.out.println("6. Выход");
            System.out.println("---------------------------------------------------------------------");
            int menuChoice = scanner.nextInt();
            scanner.nextLine();

            if (menuChoice == 1) {
                productService.addProduct(scanner);
            } else if (menuChoice == 2) {
                productService.showProducts();
            } else if (menuChoice == 3) {
                productService.editProduct(scanner);
            } else if (menuChoice == 4) {
                productService.deleteProduct(scanner);
            } else if (menuChoice == 5) {
                fileService.saveProducts(productService);
            } else if (menuChoice == 6) {
                fileService.saveProducts(productService);
                fileService.saveUsers(userService);
                break;
            }
        }
    }
}
