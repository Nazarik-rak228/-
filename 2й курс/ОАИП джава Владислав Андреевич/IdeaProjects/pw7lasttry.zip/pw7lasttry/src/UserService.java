import java.util.Scanner;

public class UserService {

    private User[] users = new User[50];
    private int userCount = 0;

    public void register(Scanner scanner) {

        System.out.println("Введите логин:");
        String login = scanner.nextLine();

        System.out.println("Введите пароль:");
        String password = scanner.nextLine();

        users[userCount] = new User(login, password);
        userCount++;
    }

    public boolean login(Scanner scanner) {

        System.out.println("Введите логин:");
        String login = scanner.nextLine();

        System.out.println("Введите пароль:");
        String password = scanner.nextLine();

        for (int i = 0; i < userCount; i++) {
            if (users[i].getLogin().equals(login)
                    && users[i].getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }
    public User[] getUsers() {
        return users;
    }

    public int getUserCount() {
        return userCount;
    }

    public void setUserCount(int userCount) {
        this.userCount = userCount;
    }
}
