
// test/validators_test.dart

import 'package:l14bd/validation/valid.dart';

void main() {
  print('ЗАПУСК ТЕСТОВ ВАЛИДАТОРОВ\n');
  
  
  print('Тесты: requareParametr');
  
  
  try {
    var result = requareParametr('  Иван  ', 'Имя');
    print(result == 'Иван' ? ' Тест 1 пройден' : ' Тест 1 провален');
  } catch (e) {
    print(' Тест 1 провален: $e');
  }
  
  
  try {
    requareParametr('   ', 'Имя');
    print(' Тест 2 провален: ошибка не вылетела');
  } catch (e) {
    print(e.toString().contains('пуст') ? ' Тест 2 пройден' : ' Тест 2 провален');
  }

  try {
    requareParametr(null, 'Email');
    print('Тест 3 провален: ошибка не вылетела');
  } catch (e) {
    print(e.toString().contains('пуст') ? 'Тест 3 пройден' : ' Тест 3 провален');
  }
  
  print(' Тесты: checkEmail ');
  

  try {
    var result = checkEmail('test@example.com', 'Email');
    print(result == 'test@example.com' ? ' Тест 4 пройден' : ' Тест 4 провален');
  } catch (e) {
    print(' Тест 4 провален: $e');
  }
  

  try {
    checkEmail('invalid-email', 'Email');
    print(' Тест 5 провален: ошибка не вылетела');
  } catch (e) {
    print(e.toString().contains('Неправильный') ? 'Тест 5 пройден' : ' Тест 5 провален');
  }
  

  try {
    checkEmail('test@domain', 'Email');
    print('Тест 6 провален: ошибка не вылетела');
  } catch (e) {
    print(e.toString().contains('Неправильный') ? ' Тест 6 пройден' : ' Тест 6 провален');
  }

  print(' Тесты: checkDate ');
  

  try {
    var result = checkDate('2026-05-14', 'Дата');
    print(result is DateTime ? ' Тест 7 пройден' : ' Тест 7 провален');
  } catch (e) {
    print(' Тест 7 провален: $e');
  }
  

  try {
    checkDate('не-дата', 'Дата');
    print(' Тест 8 провален: ошибка не вылетела');
  } catch (e) {
    print(e.toString().contains('формате') ? ' Тест 8 пройден' : ' Тест 8 провален');
  }

  try {
    checkDate('', 'Дата');
    print(' Тест 9 провален: ошибка не вылетела');
  } catch (e) {
    print(e.toString().contains('пуст') ? ' Тест 9 пройден' : ' Тест 9 провален');
  }
  
  print('Ecccccc ');
}